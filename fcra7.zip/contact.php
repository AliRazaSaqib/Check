<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8895-1" />
<title>Contact Us</title>

<meta name="keywords" content="contact fcra"/>
<meta name="description" content="This is contact us page of Crystal Consultancy. NGOs can find the address for fcra registration along with google maps."/>
	
		
		<script type="text/javascript" src="lib/jquery.tools.js"></script>	
        

<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body,td,th {
	font-size: 18px;
}
-->
</style>
<script src="js/jquery.min.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/validform.js"></script>
<script type="text/javascript">
<!--
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
//-->
</script>
	
 <!--[if IE]>
	<link rel="stylesheet" type="text/css" href="css/all-ie-only.css" />
<![endif]-->
	
	<script src="js/jquery.jcarousel.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.easing.1.3.js" type="text/javascript"></script>
	<script src="js/fancybox/jquery.fancybox-1.3.1.js" type="text/javascript"></script>	
	<script src="js/fancybox/jquery.mousewheel-3.0.2.pack.js" type="text/javascript"></script>	
	<script src="js/swfobject.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/js-func.js" type="text/javascript" charset="utf-8"></script><!--[if IE 7]>
<link href="css/ie7.css" rel="stylesheet" type="text/css">
<![endif]--></head>



<body>
  <div id="ad" style="text-align:center;"><script type="text/javascript"><!--
google_ad_client = "pub-8987062840475813";
/* 728x90, created 4/13/09 */
google_ad_slot = "4880336384";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<div id="outer-div"  style="height:1505px;"><!--main-div-strar-->

	<div class="header">
	    <div class="logo">
	      <h1>Reach Us </h1>
	    </div>
            <div class="blank-space">
				<a href="https://www.twitter.com/ngoconsultancy4/" target="_blank" class="link-with">
                	<img src="images/twitter.png" alt="foreign funding" title="foreign funds" /></a>
           				 <a href="http://www.facebook.com/fcradelhi/" target="_blank" class="link-with">
                         		<img src="images/facebook.png" alt="registration of fcra" title="fcra registration" /></a>            
            						</div>

    </div><!--header-->

<div id="navigation">
				<ul>
				    <li class="first"><a href="index.html">Home</a></li>
				    <li><a href="about-us.html">About Us</a></li>
				    <li><a href="fcra-documentation.html">Documentation</a></li>
				    <li><a href="ngo.html">NGO</a></li>
				    <li><a class="active" href="contact.php">Contact Us</a></li>	    	
				</ul>
</div><!--navigation-->
            
	<!-- Slider  -->
	<div id="slider">
		<div class="center">
		
		  <div class="slider-holder">
				<a href="#" id="prev">&amp;nbsp;</a>
				<a href="#" id="next">&amp;nbsp;</a>
				<div class="slider-content">
					<ul>
<li><img src="css/images/fcra.jpg" alt="fcra registration" /></li>
<li><img src="css/images/foreign-contribution-regulation-act.jpg" alt="foreign contribution regulation act registration" /></li>
<li><img src="css/images/fcra-registration.jpg" alt="registration of fcra" /></li>
<li><img src="css/images/foreign-funding.jpg" alt="foreign funds" /></li></ul></div>
<div class="slider-nav">
<ul>
					    <li><a href="#">1</a></li>
					    <li><a href="#">2</a></li>
					    <li><a href="#">3</a></li>
					    <li><a href="#">4</a></li>
					</ul>
				</div>
			</div>
			
	  </div>
	</div>
	<!-- Slider -->

<div id="top-content"></div>

<div id="content"  style="height:auto;">
    <div class="left">
		<div class="left-panel"><h2>Other Link</h2></div>
			<div class="left-link-panel">
            <ul>
              <li class="link-on"><a href="index.html" class="other-link">FCRA</a></li>
<li><a href="form/FC-rules2011.pdf" target="_blank" class="other-link">FC(R) Rules 2011</a></li>
<li><a href="introduction-fcra.html" class="other-link">Introduction</a></li>
<li><a href="fcra-funding.html" class="other-link">Funding</a></li>
<li><a href="offences-and-penalties.html" class="other-link">Offences &amp; Penalties</a></li>
<li><a href="form/important-dates.pdf" class="other-link">Important Dates</a></li>
<li><a href="online-application-for-fcra.html" class="other-link">Apply Online for FCRA</a></li>
<li><a href="form-descriptions.html" class="other-link">Forms &amp; Description</a></li>
<li><a href="registration-fcra.html" class="other-link">FCRA Registration</a></li>
<li><a href="consulting-services.html" class="other-link">Our Consulting Services</a></li>
<li><a href="faqs.html" class="other-link">FAQs</a></li>
<li><a href="download-form.html" class="other-link">Download forms</a></li>
<li><a href="how-apply-for-certificate-fcra.html" class="other-link">FCRA certificate</a></li></ul></div></div><!--left-panel-->

    <div class="center-panel" style="height:auto;">
	 
<div class="addressandmap">
        <div class="map">
        
        <iframe width="343" height="198" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=crystal+vision+delhi&amp;aq=&amp;sll=21.125498,81.914063&amp;sspn=37.523709,56.513672&amp;ie=UTF8&amp;hq=crystal+vision&amp;hnear=New+Delhi,+Delhi&amp;ll=28.635854,77.310233&amp;spn=0.006592,0.00912&amp;z=16&amp;iwloc=A&amp;output=embed"></iframe><br /></small>      

        
        </div>


<div class="address">
	<h5>Address</h5>
	NGO Consultancy<br />
	Office number -204, 45B, Hasanpur, 1st Floor,<br />
	I.P. Extension<br />
	New Delhi-110092<br />
	Phone No.-9873141608<br />
	9953781523<br />
	mail:<br />
	<a href="mailto:crystalvisionweb2@gmail.com">crystalvisionweb2@gmail.com</a>

</div>
</div>
	           	<div class="matter">
                  <h3>Contact Us</h3>
                 <form action="process.php" method="post" id="form1" name="form1" onsubmit="MM_validateForm('name','','R','phone','','R','email','','RisEmail','subject','','R','message','','R');return document.MM_returnValue">

                  <table width="97%" border="0">
                    <tr>
                      <td colspan="2" align="left" valign="bottom"><label for="name">Your Name:</label></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="top"><input name="name" type="text" id="name" size="80" /></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="bottom"><label for="phone">Phone NO.:</label></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="top"><input name="phone" type="text" id="phone" size="80" /></td>
                    </tr>

                    <tr>
                      <td colspan="2" align="left" valign="bottom"><label for="email">Your E-mail:</label></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="top"><input name="email" type="text" id="email" size="80" /></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="bottom"><label for="subject">Subject:</label></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="top"><input name="subject" type="text" id="subject" size="80" /></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="bottom"><label for="message">Message:</label></td>
                    </tr>
                    <tr>
                      <td colspan="2" align="left" valign="top"><textarea name="message" id="message" cols="60" rows="7"></textarea></td>
                    </tr>
                     
            <tr>
		<td class="font">Captcha Code : </td>
   <td><input name="captcha" id="captcha" class="security_coade" type="text"  value="Security Code:" onfocus='if(this.value=="Security Code:")this.value=""' onblur='if(this.value=="")this.value="Security Code:"' />
   <label><img id="siimage" src="CaptchaSecurityImages.php?characters=4&height=30&width=80" alt="captcha"></label></td>
		 </tr> 
                
                                  
                    <tr>
                      <td colspan="2"><input name="submit" type="image" id="submit" class="submit-btn" src="images/sand-message.png" onclick="MM_validateForm('name','','R','email','','R','phone','','R','subject','','R','message','','R');return document.MM_returnValue" value="Submit" /></td>
                    </tr>
                  </table>
                 </form>
                 <br />
                  
</p>
</div>


    </div><!--center-panel-->
        <div class="right-panel">
        	<div class="right-panel-heading"><h2></h2></div>
<div class="right-panel-matter">
   <script type="text/javascript"><!--
google_ad_client = "pub-8987062840475813";
/* 120x600, created 07/10/10 */
google_ad_slot = "2978876793";
google_ad_width = 120;
google_ad_height = 600;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
      
             
            
            
            
            
            
            
            </div>        
        </div>
</div><!--content-->

<div id="bottom-content"></div>
</div><!--outer-div-->
<div id="footer">
	<div class="footer-box">
		<div class="footer-content">
			<p><a href="index.html" class="foot-link">Home</a> | 
			<a href="sitemap.html" class="foot-link">Site Map</a>|
			<a href="services.html" class="foot-link">Services</a>|
			<a href="contact.php" class="foot-link">Contact Us</a>|
			<a href="faqs.html" class="foot-link">FAQ</a></p>
	<hr style="color:#538ba;f" />
    		<p class="copyrite">Copyright are reserved of this website@ <span><a href="http://www.fcra.co.in/">www.fcra.co.in</a></span><br />
2011-2012</p>
        </div>
		<div class="footer-divider"></div>
		<div class="footer-content">
			<p class="quick-contact"><u>Quick Contact</u></p>
			<p class="add">NGO Consultancy, Office number -204,</p>
<p class="add">45B, 1st Floor, Hasanpur, I.P. Extension</p>
<p class="add">New Delhi-110092</p>
<p class="add">Phone No.-9873141608, 9953781523</p>
<p class="add">E-mail: <a href="mailto:crystalvisionweb2@gmail.com">crystalvisionweb2@gmail.com</a></p>
      
        </div>

    </div>
</div>
</body>
</html>
